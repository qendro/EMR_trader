# Architecture

EMR-HyperNEAT is a **layer on top of TensorNEAT**, not a fork of it. TensorNEAT provides the
NEAT/CPPN engine (evolving a genotype network and querying it); EMR-HyperNEAT builds the adaptive
substrate from those queries and evaluates it. This page explains the
layer the project adds and how the modules fit together. TensorNEAT internals are treated as a black
box that you never call directly.

## What EMR-HyperNEAT adds

ES-HyperNEAT decides *where to place neurons* by recursively subdividing space with a sequential
quadtree driven by CPPN-output variance. That quadtree is serial and CPU-bound, which caps the
method at small substrates. EMR-HyperNEAT replaces it with:

- **Eager multi-resolution substrate discovery**: a pre-computed hierarchical grid (4^(level+1)
  candidate positions per level) is evaluated all at once as batched tensor arithmetic that `vmap`s
  across the whole population, instead of one quadtree per genome.
- **Post-hoc variance masking**: after the eager evaluation, a cell below the top level is reached
  when its parent was reached and the variance of the CPPN outputs over the parent's four children
  passes a threshold (under the default `variance_rule: canonical`), the gate ES-HyperNEAT's
  quadtree applies. Every reached cell, at every level, is a node. The position sets can still
  differ: the mask reads the first input's CPPN outputs, where ES-HyperNEAT grows one tree per
  input; EMR's variance threshold (0.03) applies to raw CPPN outputs, ES-HyperNEAT's (0.5) to
  weights scaled to [-5, 5]; and EMR keeps connections by weight magnitude rather than by
  ES-HyperNEAT's band test.

<p align="center">
  <img src="figures/hierarchical_grid.png" width="820" alt="Multi-resolution candidate grid at depths 1 to 4">
</p>
<p align="center"><em>The eager grid. Candidate positions densify with depth (4, 20, 84, 340 positions with 1 to 4 levels, that is max_depth 0 to 3). Every position is evaluated in one batched pass, rather than being reached by sequential subdivision.</em></p>

<p align="center">
  <img src="figures/variance_masking.png" width="820" alt="Post-hoc variance masking from CPPN weights to active positions">
</p>
<p align="center"><em>Variance masking selects the sparse substrate. The CPPN weight field (left) is reduced to per-region variance (center), and regions above threshold stay active (right).</em></p>

On top of that substrate engine, the same package adds four evolvable *feature dimensions*:

- **Per-node dynamic activation functions**: each node can use a different activation, selected
  from an 18-function palette (see [configuration](configuration.md)). Oscillatory activations such
  as `sin` solve feed-forward parity beyond XOR, which monotonic activations almost never do: on
  Parity-4, `sin` reaches the 0.95 threshold in 30 of 30 runs and nine of the ten monotonic
  functions in none (recurrence changes this).
- **Per-node aggregation functions**: how a node combines its inputs (sum/mean/min/max/...): one
  function for every node, or per node from the CPPN or the incoming weights (see
  [configuration](configuration.md)).
- **Neuromodulation**: neurotransmitter vectors `[DA, 5HT, NE, ACh]` modulate node behavior, which
  enables one substrate to solve several tasks (multi-task).
- **Hidden-to-hidden recurrence**: the hidden layer settles for a fixed number of steps on each
  input, from zero every time, so no state carries between inputs (the h->h connection cache is
  off by default).

Plus engineering for scale: a JIT cache and optional multi-GPU sharding.

## How a generation is computed

One generation takes the population from CPPN genomes to fitness values in six steps. Steps 2–4 are
the substrate discovery EMR replaces relative to ES-HyperNEAT; steps 1 and 6 are plain NEAT,
delegated to TensorNEAT.

1. **Ask.** TensorNEAT emits the generation's CPPN population and transforms each genome into
   query-ready arrays.
2. **Query the grid.** The candidate substrate is a pre-computed multi-resolution grid: level *l* is
   a `2^(l+1) × 2^(l+1)` lattice of `4^(l+1)` cells, and each level-*l* cell maps to four children at
   level *l+1* (340 candidate positions in total at `max_depth: 3`). For every (genome, source
   node, candidate position) triple the CPPN is evaluated on the input vector
   `[x1, y1, x2, y2, bias]`, or a 7-input variant that adds the source->target offsets when geometry
   seeding is enabled. The whole query is one batched tensor computation `vmap`ped across the
   population; nothing is sequential per genome.
3. **Mask by variance.** Within each region of the grid, the variance of the CPPN's output field
   decides whether that region carries structure. A reached cell's four children are reached when
   the variance of their outputs passes `variance_threshold` (under the default
   `variance_rule: canonical`); below it the cell stays a node, but its children are not reached.
   What is reached is the sparse **active set**, found by filtering the eager evaluation instead of
   by recursive subdivision; as in the quadtree, a region is reached only through its parent
   (`initial_depth` can force the first levels fully active regardless of variance).
4. **Build the weight matrices.** The substrate is materialized as two dense matrices:
   `W1` with shape `(num_inputs, num_positions)` and `W2` with shape `(num_positions, num_outputs)`.
   Dense is deliberate: input->hidden and hidden->output remain GPU-efficient matmuls even though
   variance masking zeroes most positions.
5. **Evaluate.** The feedforward pass is two lines: `h = tanh(inputs @ W1)`, then
   `sigmoid(h @ W2)`. Per-node dynamic activations and aggregations replace the fixed `tanh` when
   enabled, and neuromodulation multiplies in per-node gains and gates (one rule on every path,
   `neuromodulation.node_rule`), a *parametric* modulation
   on top of the *structural* choice the dynamic functions make; the two are orthogonal and
   composable. With recurrence, hidden->hidden is the hybrid part of the architecture: h->h
   connections are **sparse** (discovered per genome over the active set), assembled once into a
   `Whh` matrix and applied as a matmul inside `activate_time` settling steps, while W1/W2 stay
   dense. Each step applies the node's whole feed-forward transformation to the input drive plus
   the recurrent input, `h = f(drive + h @ Whh)` from `h = 0`, so without h->h connections the
   recurrent path computes the feed-forward one
   ([configuration](configuration.md#feature-1-dynamic_functions-per-node-activation); in
   0.1.0 its default applied no configured activation). One per-genome function serves both the
   population's fitness and `evaluate_on_data`, so a held-out score is computed on the network that
   was evolved.
6. **Tell.** Per-genome fitness goes back to TensorNEAT's NEAT, which selects, speciates, and
   mutates the CPPNs for the next generation.

### The substrate on its own

Steps 2 to 5 of the feed-forward standard path are public functions in `emr_hyperneat.substrate`,
for tools that need the substrate rather than a fitness: to draw it, to render what it computes,
or to run it on other inputs. The generation loop builds and evaluates its substrate through the
same functions, and `tests/test_substrate_api.py` checks bit for bit that the public calls return
the arrays and fitness the loop computes.

```python
algo = EMRHyperNEAT()
cfg = algo.create_config(params)
state = algo.initialize(cfg, problem)
substrate = algo.population_substrates(state)   # W1, W2, mask, per-node indices per genome
outputs = substrate_forward(substrate, inputs)  # (pop, samples, outputs)
```

A tool with its own CPPN evaluator takes the query rows from `substrate_queries(config)`,
evaluates them, and passes the outputs to `build_substrate`. The evaluator must compute exactly
what the model's CPPN computes, output transform included.

Hidden-to-hidden connections take two more steps, the caller evaluating the CPPN again:
`hh_query_rows(substrate)` gives, per genome, the rows of every ordered pair of its active
positions (sources and targets in ascending position order, source-major), and
`build_recurrent_substrate(substrate, hh_outputs)` turns the outputs into the generation loop's
connections: `hh_from`, `hh_to`, `hh_weights`, `hh_valid` in the loop's layout of
`max_sparse_conns` slots, plus `hh_class` (forward, lateral, backward or self, by the
positions' y), `hh_direct` (a direct connection at its own weight, not a composite of the
multi-hop expansion) and `hh_uncapped` (connections before the cap). The build runs the loop's
per-genome discovery arithmetic (`per_genome_pair_connections`, with the band criterion
`hh_pair_weights`) on the loop's bucket shapes, so its connections are the loop's bit for bit,
and one genome built alone gives the arrays it has in its population. `substrate_forward`
settles each genome on its own active positions with the loop's node function, and
`return_states=True` also returns the hidden state after each settling step, one array per
genome over its own positions. It settles `SubstrateConfig.activate_time` steps (None:
`2 (2**max_depth + 1)`), the count the configuration names in either block; a count that is not an
integer of at least 1 is refused there as in the configuration, and a feed-forward substrate ignores
it. The loop evaluates a recurrent population on the union of its
active positions, so the forward matches the loop's fitness within float32 rounding, not bit for
bit; on a GPU the two layouts round differently and a settling that amplifies rounding can move
a genome's fitness by more (`tests/test_substrate_recurrent.py`). A genome whose mask a caller
has cleared entirely has no hidden node: `(0, input_dim)` rows, no connections, settling states
of width 0, and the outputs the feed-forward forward gives with every column zeroed (the output
activation of zero). A mask the library builds always keeps the four positions of the coarsest
level.

True neuromodulation (level 4) of a feed-forward substrate is in the API as the loop runs it, with
receptors from the weights. `substrate_config` carries the configuration's settings in
`SubstrateConfig.neuromodulation` (a `NeuromodulationSettings`), and `substrate_forward` then applies
the loop's node rule and output inversion, bit for bit. `substrate_neuromodulation(substrate)`
returns what the nodes read, a `SubstrateNeuromodulation`: each hidden position's receptor densities
and base gain, derived from its first input weight as the loop derives them, and the
neurotransmitter vector (by default the loop's single-task vector, `default_neurotransmitter`). A
caller may build its own, for example from another summary of a node's weights through
`derive_receptor_from_weight`, and pass it as `substrate_forward(substrate, inputs,
neuromodulation=...)`: the loop's rule applies to whatever it is given. Under neuromodulation the
configured output activation applies, as in the loop. An aggregation palette
(`aggregation.palette`, any subset of `AGGREGATION_LIST` in any order) is decoded as the loop decodes
it (`SubstrateConfig.aggregation_palette`).

The substrate's own steps are public as well, with parameters the API keeps from release to release
(`tests/test_substrate_api.py` pins them): `get_hierarchical_grid(max_depth)` (the candidate
positions by level), `cppn_query_rows` (the CPPN's input rows for one endpoint against many),
`compute_hierarchical_variances_batch` (the variance per level that the mask thresholds),
`cppn_output_function_indices` (a node's function index from a CPPN channel),
`substrate_weight_matrices` (pruned, locality-scaled `W1` and `W2`) and `self_connection_rows`.
`SUBSTRATE_CAPABILITIES` names what the API covers, for a caller that checks before it asks:
`sparse_cap_policy`, `neuromodulation`, `aggregation_palette` and `substrate_steps`. What a node
computes, without the rest of the engine, is in `emr_hyperneat.vocabulary`: the activation and
aggregation functions, the neurotransmitter vectors, `derive_receptor_from_weight`, the node rule
(`true_neuromodulation_node_fn`) and `invert_outputs`, each the engine's own object.

Outside the API's scope, and refused by `substrate_config`: neuromodulation other than true
neuromodulation of a feed-forward substrate with receptors from the weights (other modes, receptors
from dedicated CPPN outputs or from the self-connection query, branch gating, a recurrent substrate),
multi-task, swarm mode, LEO, palette evolution, the weight-interpretation and random function modes,
an execution mode other than `standard`, the union h->h discovery, dense discovery and the h->h
cache.

### The recurrent path: multi-hop expansion and the h->h cache

Direct h->h connections come from thresholded CPPN queries over pairs of active positions.
`iteration_level` *k* then expands them transitively by repeated matrix products. With A the
genome's direct connections (the masked adjacency), the engine forms the hop terms decay^(h−1)·A^h
for h = 1..k and keeps, per pair, the term of largest magnitude (a max merge, not a sum, so a strong
direct connection is never replaced by a weaker indirect one); each product is thresholded at the
band before the decay, and the result is clipped to `max_weight`:

```
A_total[i,j] = the largest-magnitude term among A[i,j], decay·A²[i,j], …, decay^(k−1)·A^k[i,j]
```

so that if A->B and B->C exist, an attenuated A->C is added (`hop_decay_factor` is the decay), and
the expanded set is intersected with the preset's connection class, so a composite that would land
in a class the preset forbids is dropped. Every hop is an existing direct connection
(`recurrence.multi_hop_second_factor: masked`, the default since 0.2.0). The expansion is
JIT-compatible because *k* and the second factor are static arguments, so the Python loop compiles
away.
Discovery is the expensive step, so it can be cached at two levels: JAX's persistent compilation
cache (cross-run, keyed on shapes), and the in-run `HHCacheManager` (off by default since 0.2.0),
which skips re-discovery while the variance mask is stable and refreshes every
`hh_refresh_interval` generations or when the mask moves by more than `hh_mask_change_threshold`.
The in-run cache changes what is evaluated, not only how fast: its connection set is indexed by
population slot, and reproduction moves genomes between slots, so between refreshes a genome is
scored with the recurrent connections discovered for whichever genome held its slot at the last
refresh. That is why it is off by default; `hh_cache_enabled: true` reproduces a cache-on run (see
[configuration](configuration.md)). A cache keyed by genome
content would be sound but would only serve genomes unchanged since the last discovery (the elites),
a few percent of a NEAT population, so it would recover almost none of the time; the saving the
slot cache produced came from skipping discovery for genomes that had changed. Discovery itself is
where the cost sits (80 to 90% of a cache-off generation at depths 2 to 6 on XOR at population 1000
on an RTX 2080 Ti, with the union query). The union query evaluates the CPPN over the population's
union of active positions, so a per-genome or bucketed query is the result-preserving way to make it
cheaper. `recurrence.hh_discovery_mode: per_genome`, the default, buckets the genomes by their
active-position count into static sizes (8, 16, 32, ...) and evaluates each bucket's CPPNs over
the genomes' own position pairs in slices of a fixed number of genomes per bucket size (at most 2^16
pairs per call; a short slice is padded with a repeated member whose rows are dropped at the
scatter), the whole population in one call, so each bucket size compiles once per run. From bucket
size 1024 on, a slice's query runs over blocks of source positions in sequence (at most 2^18 pairs per
block), so one call's temporaries stay near 120 MB instead of growing with the square of the bucket
(1.9 GB at 2048). It returns the
union path's connections and weights at every level (bit for bit on a CPU at level 1, and at level 2
across 36 configurations; a GPU fuses the same per-pair arithmetic
differently by batch shape and lands 1 to 6 float32 ulps away at level 1, up to about 28 against the
reference formula at level 3, with identical connection sets; the criterion stays "same connections,
weights within a few ulps"). In 0.1.0 the union implementation
computed each hop as `A_current @ W` with `W` the raw weights over the whole union of active
positions rather than the masked `A`, so a genome's 2-hop connections could end on positions it did
not have active, run against its connection class, and change with the other genomes in the
population (on XOR at depth 3 with 30 genomes, 78% of the level-2 connections left the genome's
active set), and it carried the decayed product into the next hop (hop 3 at decay³ instead of
decay²). Since 0.2.0 both query modes compose the masked `A` on every hop;
`multi_hop_second_factor: raw` reproduces 0.1.0's expansion bit for bit and is refused together with
`per_genome` (faster than union at every depth 1 to 7 on XOR, population 1000, an RTX 2080 Ti, with
identical results). After every discovery
call the module-level `emrhyperneat._last_discovery_stats` holds per-genome direct and total
connection counts, the direct connections whose weight the merge replaced, each genome's count
before the `max_sparse_conns` cap (the cap's policy applies after the record), active positions
and the union size, for experiment records; the generation's metrics read the largest set from it. The pmap pipelines (multi-GPU
strategies) take direct connections only, at `iteration_level` 1, found once per generation
outside the pmap by the discovery `single_gpu` runs (in 0.1.0 each device discovered them itself,
over every pair of grid positions); they apply the connection class like the standard path, and
both pmap runners refuse a level above 1 and the features their tanh/sum evaluation drops on entry
(in 0.1.0 a level-2 preset ran there as level 1 while `effective_iteration_level` recorded 0),
recording `effective_iteration_level` 1. Level 0 runs there as level 1, as on the standard path;
0.1.0 passed it on as 0, which these pipelines read as feed-forward (no hidden-to-hidden
connection). The check
runs at dispatch because the same configuration falls back to the standard path on one device or on
a dataset under 16 rows per device, where level 2 is computed.

### Why the three execution modes compute the same thing

The execution modes never change *what* is computed, only where the intermediate arrays live.
(This holds under either `variance_rule`. Under `legacy`, which the EMR paper runners pin,
streaming and depth_offload apply the standard path's original level-0 rule; in 0.1.0 they ran the
canonical rule instead.)

- **`standard`** queries every candidate position at once. Highest peak memory, and the
  path the golden tests lock.
- **`streaming`** builds the weight matrices level by level, so one level's queries, and the next
  level's input queries for its variance, are resident at once; W1 and W2 are still assembled at
  full size.
- **`depth_offload`** also keeps the assembled matrices in host RAM (or a memmap) and moves
  each chunk to the device only to evaluate it. It is the only mode that reaches depth 11+, where
  the matrices exceed device memory outright.

The three share the subdivision rule as one function, not as copies: a cell is reached when its
parent was reached and subdivides, forced up to `initial_depth` and by variance above the threshold
after it. The standard path's masks, the streaming build and depth offload's level loop, which
both of offload's generations run, each call it.

`streaming` swaps one step inside the normal generation loop, so it composes with everything else
the loop does. `depth_offload` cannot: never materializing the full matrices means its build and its
evaluation are fused, so it replaces the generation rather than a step within it. That asymmetry is
why the dispatcher has two extension points rather than one. Knobs and auto-selection rules:
[configuration](configuration.md#execution-mode).

### What the multi-GPU strategies parallelize

Multi-GPU execution engages **only through `run_until_threshold`** (`run_generation` is
single-device by design), and only with 2+ visible devices; the island model also runs its islands
on one. Each strategy answers one question: what is split across the GPUs, and what is replicated on
each?

| Strategy | Split across GPUs | Replicated per GPU | Use when |
|---|---|---|---|
| `single_gpu` | nothing | everything | one device, debugging, small runs |
| `full_pipeline_parallel` | the **dataset** | population + the full pipeline | the feedforward default. Runs on one device instead when the problem sets `is_exhaustive_dataset` or has fewer than 16 samples per device (XOR has 4). With hidden-to-hidden connections it runs `iteration_level` 1 only and refuses a higher level; the masks and the connections are then found once per generation, on one device, by the discovery `single_gpu` runs, and replicated (0.1.0 discovered them on every device over every pair of grid positions, which ran out of memory at depth 4 and population 100) |
| `eval_only_parallel` | evaluation samples | weights (broadcast) | recurrent/h->h runs at any iteration level: discovery, multi-hop included, and W1/W2 stay on one device (`full_pipeline_parallel` refuses levels above 1) |
| `population_parallel_process` | the **population** (one OS process per device, each with its own JAX runtime) | the dataset | **not recommended.** The least exercised path here. Hidden-to-hidden connections are discovered on one device and scored with the kernel `eval_only_parallel` uses; a worker that fails raises. Development measurements made outside this repository, not reproducible from it, with every worker on the first GPU (as in 0.1.0), found it far slower than single-device and returning zero best fitness at large populations: at population 1000 every worker ran out of GPU memory |
| `streaming` | nothing (one device) | - | deep substrates, querying the CPPN one level at a time |
| `population_pmap` | the one-output CPPN query and the evaluation, by **genomes** | the data, for the evaluation; the rest of the generation (masks, hidden-to-hidden discovery at any iteration level, compaction) runs once, on the first device | any configuration the standard generation runs, recurrent ones included, when the query and the evaluation dominate. Equal to `single_gpu` bit for bit on CPU devices, to float32 rounding on GPUs. Grid: [`parallel`](configuration.md#parallel-the-split-routes-device-grid) |
| `position_sharding` | the one-output CPPN query by **grid positions**; the evaluation by genomes | as `population_pmap` | as `population_pmap`, when the grid holds many positions |
| `hybrid` | the query over a grid of `population_devices x position_devices` devices; the evaluation by genomes over all of them | as `population_pmap` | as `population_pmap`, on four or more devices |
| `island_model` | the **population**, as islands that evolve apart in lockstep and exchange their best genomes | nothing: each island is a `single_gpu` run on its device | a population-structure experiment: it changes the evolution (each island selects within itself), not only where it runs. Configuration: [`islands`](configuration.md#islands-the-island-model) |

The parser also accepts thirteen older alias names and maps them onto these nine: `multi_gpu`,
`data_parallel` and `pipeline_chunked` become `full_pipeline_parallel`; `pmap_parallel` becomes
`eval_only_parallel`; `population_parallel_sequential` and `persistent_parallel` become
`population_parallel_process`; `population_parallel` becomes `population_pmap`; `position_pmap`,
`shard_map`, `cppn_chunked` and `position_sharding_chunked` become `position_sharding`;
`island_model_v2` becomes `island_model`; `baseline` becomes `single_gpu`. In 0.1.0 the
configuration key ran `cppn_chunked` as `streaming` and `position_sharding_chunked` as
`full_pipeline_parallel`, and warned at the names of the split routes and the island model and ran
`single_gpu`; the prototype engine ran the two chunked names as a CPPN query split by grid position.
The constructor's `strategy` argument maps the same names the same way (`STRATEGY_NAME_MAP` in
`emr_hyperneat.emrhyperneat`), so every `MultiGPUStrategy` member has a route. In 0.1.0 only
`streaming`, `eval_only_parallel` and `population_parallel_process` kept their multi-device route
through the constructor: it mapped `full_pipeline_parallel`, `multi_gpu`, `data_parallel` and
`cppn_chunked` to strategies without one and kept the other aliases as they were, so such a run took
the one-device loop under the requested name.

Speed is deliberately absent from this table. The per-strategy ratios that used to sit in the
code's docstrings traced to a development note with no result file behind them, and later
measurements disagreed with them. Pick by the memory and correctness columns, then measure on your
own hardware.

## Component diagram

```mermaid
flowchart TB
    subgraph YOURS["Your experiment (your code)"]
        PROB["Problem object<br/><i>get_data() → list of (input, target)</i>"]
        CFG["Config dict<br/><i>substrate + feature settings</i>"]
    end

    subgraph PKG["emr_hyperneat, the public package"]
        API["<b>EMRHyperNEAT</b> (public API)<br/>create_config · initialize · run_generation"]

        subgraph LAYER["The EMR layer (what this project adds)"]
            SUB["Eager multi-resolution<br/>substrate discovery<br/>+ variance masking"]
            DYN["Per-node dynamic<br/>activation &amp; aggregation"]
            NMOD["Neuromodulation<br/>(NT vectors · multi-task)"]
            REC["h→h recurrence<br/>+ connection cache"]
            GPU["Multi-GPU sharding"]
        end

        subgraph COMPAT["_compat, vendored shim (internal)"]
            BASE["BaseAlgorithm /<br/>AlgorithmMetrics"]
            SCHEMA["Config schemas<br/>+ config manager"]
            ADAPT["TensorNEAT adapter"]
        end
    end

    subgraph TNEAT["third_party/tensorneat, submodule (black box)"]
        ENGINE["NEAT / CPPN engine<br/>ask · tell · transform<br/>Pipeline · ACT / AGG registries"]
    end

    DATA["papers/ + Zenodo data release<br/><i>reproduce the published results</i>"]

    PROB --> API
    CFG --> API
    API --> LAYER
    LAYER --> COMPAT
    COMPAT --> ENGINE
    API -. "metrics (best_fitness, …)" .-> YOURS
    DATA -. "uses the same API" .-> API
```

Data flows down (your problem + config -> the API -> the EMR layer -> the shim -> TensorNEAT);
fitness metrics flow back up to your loop. The data release sits to the side: you only touch it
when reproducing the published results.

## Module map

Everything is under `emr_hyperneat/`.

### Public: what you import and call

| Module | Role |
|---|---|
| `__init__.py` | The public surface: `EMRHyperNEAT` and the substrate API below. |
| `substrate.py` | The substrate outside the generation loop, feed-forward or with hidden-to-hidden connections: `SubstrateConfig`, `substrate_queries`, `query_substrate`, `build_substrate`, `substrate_forward`, `hh_query_rows`, `build_recurrent_substrate`, `query_recurrent_substrate`; true neuromodulation (`NeuromodulationSettings`, `substrate_neuromodulation`, `SubstrateNeuromodulation`), the substrate's steps and `SUBSTRATE_CAPABILITIES`. See [The substrate on its own](#the-substrate-on-its-own). |
| `vocabulary.py` | What a node computes, without TensorNEAT or the configuration schemas: the activation and aggregation functions, the neurotransmitter vectors, the neuromodulated node rule and the output inversion, each the engine's own object. |
| `emrhyperneat.py` | The `EMRHyperNEAT` class and the feature layer: per-node dynamic activation/aggregation, neuromodulation, multi-task, the h->h cache, and the config dataclasses. The class is assembled from the mixins in `engine/`, and every name of the engine is importable from here, as when the engine was this one file: `ACTIVATION_LIST` (the 18 activations), `PALETTE_CONFIGS`, the presets, the dataclasses. |
| `emrhyperneat_base.py` | The engine beneath the class: eager multi-resolution substrate discovery, recurrence/cache config, the `MultiGPUStrategy` names (`emrhyperneat.py` routes them), and the **TensorNEAT integration seam**. |
| `execution/` | The three execution modes: how a generation moves its intermediate arrays through memory. `ExecutionMode` and `ExecutionConfig` in `__init__.py`, memory arithmetic in `chunking.py`, and the two non-standard strategies in `streaming.py` and `offload.py`. See [Configuration](configuration.md#execution-mode). |
| `fitness_utils.py` | Ready-made fitness functions (binary / multi-class / regression) for benchmarks. |
| `multi_gpu_worker.py` | Worker processes for true multi-GPU runs (each owns its JAX runtime). Not needed for single-device use. |

You construct `EMRHyperNEAT()` and call its methods (see
[Writing experiments](writing-experiments.md)); the substrate functions are for inspecting what
it evolves.

### Internal: you do not import these directly

| Module | Role |
|---|---|
| `_compat/` | A small vendored **compatibility shim** that keeps the package self-contained: it provides `BaseAlgorithm` + `AlgorithmMetrics` (the base class and the metrics object), the Pydantic config schemas, the **TensorNEAT adapter**, and the config/parameter manager. No external framework is required. |
| `engine/` | The engine's code by concern, behind `emrhyperneat.py`: the configuration vocabulary, the node functions and palettes, settling, neuromodulation, multi-task, LEO, the substrate build and CPPN queries, evaluation, h->h discovery, the device splits and islands, the pmap kernels, and the class's methods as mixins (one generation, the routes, configuration parsing, the execution modes, multi-task evaluation, the multi-device pipelines, the champion and continual learning, palettes, the prototype's names). The docstring of `emrhyperneat.py` maps them. Import from `emrhyperneat`. |
| `node_list.py` | The prototype's node-list recurrent model, opt-in with `recurrence.network_model: node_list`: a whole population's networks on the leaves of a complete quadtree, discovered in one compiled call. See [Configuration](configuration.md#the-prototypes-node-list-model). |
| `tests/` | The test suite (see [Testing](testing.md)), including `test_paper_validation.py`, which re-runs the simple paper experiments. |

## The TensorNEAT seam (the black box)

EMR-HyperNEAT reaches TensorNEAT through exactly two narrow seams, both inside the package internals:

1. The `_compat` **adapter** (`_compat/adapters/tensorneat_adapter.py`) builds the NEAT algorithm and
   its config and pulls TensorNEAT's activation/aggregation registries.
2. The **engine** (`emrhyperneat_base.py`) lazily imports TensorNEAT's HyperNEAT genome pieces, the
   `RecurrentGenome` (whose `forward` is the CPPN query), and the `Pipeline` driver, then JIT-compiles
   the ask/transform/tell cycle: steps 1 and 6 of [how a generation is computed](#how-a-generation-is-computed).

Everything the project adds (the eager grid, variance masking, batched CPPN queries across the
population, dynamic per-node functions, neuromodulation, and the caches) lives above this seam. You
do not need to understand NEAT or CPPNs to use EMR-HyperNEAT; you configure the substrate and the
feature dimensions, and the engine does the rest.

Next: [Writing experiments](writing-experiments.md) to use the API, or the
[configuration reference](configuration.md) for every knob.
